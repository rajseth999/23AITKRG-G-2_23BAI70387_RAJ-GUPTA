import React, { useState, useEffect } from "react";

function BuggyCounter() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCount(count + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return <h3>Count: {count}</h3>;
}

export default BuggyCounter;