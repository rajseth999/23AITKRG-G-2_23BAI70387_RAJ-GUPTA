import React from "react";
import BuggyCounter from "./BuggyCounter";
import FixedCounter from "./FixedCounter";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Stale Closure Demo</h1>

      <h2>Buggy Counter</h2>
      <BuggyCounter />

      <h2>Fixed Counter</h2>
      <FixedCounter />
    </div>
  );
}

export default App;