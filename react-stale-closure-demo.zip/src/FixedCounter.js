import React, { useState, useEffect } from "react";

function FixedCounter() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCount(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return <h3>Count: {count}</h3>;
}

export default FixedCounter;